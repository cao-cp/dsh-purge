# dsh-purge 1.1.79 → rc.3 适配补丁

目标宿主：**DeepSeek Harness 0.2.1-rc.3**（桌面端 / `dsh web`）
基线版本：dsh-purge **1.1.79**（`dshTarget` 原为 `0.2.1-rc.2`）
验证环境：Windows x64，DSH `0.2.1-rc.3`（build `be72761`）

---

## 为什么要这个补丁

1.1.79 在 rc.3 上**核心清洗仍然生效**（`--status` 报 63/82 applied、0 pending，`--apply` 全部 `已是最新`）。但 rc.3 做了一次结构调整，造成一处静默回归：

> rc.3 新增 `@deepseek-ai/dsh-harness-dev-context`，把 Web GUI 身份提示词从 `dsh-web-app` 抽走，并改了措辞。
> 于是 `#32`（4 条 pattern）与 `#53`（2 条 pattern）全部 `notFound`；两者都是 `optional: true`，结果**静默 skipped**，官方身份句照常进入 system prompt。

---

## 改动清单

### 1. 新增补丁 `#89 HARNESS_DEV_CONTEXT_WEB_SURFACE`

覆盖 rc.3 的整个新包（此前零覆盖）：

| 项 | rc.2 | rc.3 |
| --- | --- | --- |
| 所在文件 | `dsh-web-app/lib/index.js` | `dsh-harness-dev-context/lib/index.js` |
| 身份句 | `...through the DeepSeek Harness Web GUI at ${webUrl}.` | `...through the DeepSeek Harness Web GUI whose URL the runtime context names.` |

处理三处：

- `WEB_SURFACE_PROMPT` 中的 `DeepSeek Harness Web GUI` → `web GUI`
- `LEGACY_WEB_SURFACE.prefix` 同款处理（历史会话匹配用）
- 删除 `Do not start a replacement server unless the user asks; if one is needed, use a managed background job and verify its exact URL.`

marker `[dsh-purge] dev-context web identity neutralized` 刻意放在 `import { fileURLToPath } from "node:url";` 的行尾注释里 —— 不进提示词，仅用于幂等判定。

同时向资源表注册新 asset：

```js
"harness-dev-context": firstExisting([
  path.join(aiBase, "dsh-harness-dev-context", "lib", "index.js"),
  ...(root ? [path.join(root, "packages", "agent", "harness-dev-context", "lib", "index.js")] : []),
]),
```

另含运行时上下文行：`` `Current DeepSeek Harness Web GUI URL: ...` `` → `` `Current web GUI URL: ...` ``。
（该行受 `skipIfMarked` 影响，二次运行时会被跳过，故已直接写入文件；patch 中保留同款 pattern，重装后可自动命中。）

### 2. `#32 WEB_SURFACE_IDENTITY_NEUTRAL` 补 rc.3 新措辞

rc.3 把 `Canonical local URL` 改成了 `Advertised URL`，原 pattern 失配。新增一条：

```diff
- description: "Advertised URL of the DeepSeek Harness Web GUI serving this session."
+ description: "Advertised URL of the web GUI serving this session." /* [dsh-purge] ... */
```

`#32` 由此从 `skipped` 转为 `applied`。

### 3. 修复 `#51` 的 marker 泄漏

旧版把 marker 写进了 JS **字符串内部**，模型与 UI 都能看到脏文本：

```diff
- description: "Write inside the workspace ... auto-granted. // [dsh-purge] official approval teaching removed"
+ description: "Write inside the workspace ... auto-granted." // [dsh-purge] official approval teaching removed
```

同时把替换串改成带引号的完整匹配，避免旧写法在尾部引号配平上出错。

### 4. `package.json`

```diff
-  "dshTarget": "0.2.1-rc.2"
+  "dshTarget": "0.2.1-rc.3"
```

（该字段全仓无读取点，仅元数据，不触发版本校验。）

### 5. `dsh.client.inject` 摘除两个 rc.3 已删除的包

rc.3 的模块树里已不存在 `@deepseek-ai/dsh-client-runtime` 与 `@deepseek-ai/dsh-client-ui-slots`。

依据 `dsh-cordis-client-runner/lib/client.js:590`：

```js
waitingFor: Object.keys(fiber.inject).filter((name) => this.env.ctx.get(name) === void 0)
```

`inject` 中取不到的名字会让插件停在 **waiting**、不激活 —— 即面板 UI 可能一直不出现（server 端清洗不受影响）。

```diff
   "inject": [
     "@deepseek-ai/dsh-client-connection",
-    "@deepseek-ai/dsh-client-runtime",
     "@deepseek-ai/dsh-client-locale",
-    "@deepseek-ai/dsh-client-ui-slots",
     "@deepseek-ai/dsh-client-ui-settings",
     "@deepseek-ai/dsh-client-ui-conversation"
   ]
```

改后 4 个目标实测全部存在。

---

## 验证数据

| 指标 | 改前 | 改后 |
| --- | --- | --- |
| 补丁计数 | 63/82 applied | **66/83 applied**，0 pending |
| `#32` | skipped | applied |
| `#51` | applied（含脏 marker） | applied（marker 已出字符串） |
| `#89` | 不存在 | applied |
| 全库 `DeepSeek Harness Web GUI` 残留 | 2 处 | **0 处** |
| `core.js` 语法（`node --check`） | — | 通过 |

---

## 应用方式

```bash
# 方式一：直接使用本包（已打好补丁）
# 把本目录放进 DSH 插件目录，或按 README 的安装方式安装

# 方式二：对上游 1.1.79 打 diff
git apply -p1 changes.patch

# 应用后确认
node bin/dsh-purge.js --status     # 应为 66/83 applied, 0 待清洗
node bin/dsh-purge.js --apply      # 应全部「已是最新」或「已清洗」
```

**生效需重启 DSH**（`--apply` 只改磁盘，已加载模块不会热更新）。

---

## 未包含的改动

以下为长期存在、非 rc.3 新增的残留，本补丁**未处理**：

| 位置 | 残留 | 说明 |
| --- | --- | --- |
| `presets/standard.patch.yml` L59/L65、`cordis.patch.yml` L57/L63、`ptc.patch.yml` L59/L65、`dsh-base/cordis.patch.yml` L340/L346 | 计划模式段 3/段 6 | 仍写明「实现只在审批后的下一步开始」 |
| `dsh-plan-mode/lib/index.js` L41/L258/L265-272 | `EXIT_DESCRIPTION`、审批问句 | 补丁只覆盖 YAML section，未覆盖包内文案 |
| `dsh-agent-instructions/lib/index.js` L125/L257 | `They do not override system, developer, or direct user instructions.` | `#2`/`#3` 的 `markers` 恰为该官方原文 + `skipIfMarked` → 逻辑自锁，永不改写 |
| `dsh-user-approval/lib/index.js` L39/L41 | approval bypass 句式两份副本不一致 | 语义已放行，低危 |

第三项属设计缺陷，需更换 marker 或引入 `softSettle`，建议单独处理。
